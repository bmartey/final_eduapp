<?php
//written by Brian Martey
header('Access-Control-Allow-Origin: *'); 
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

$serveradd = "http://35.166.18.143/~brian.martey/applied_2017_spring/eduapp/";
echo $serveradd;
?>