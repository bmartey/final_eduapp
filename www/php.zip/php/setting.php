<?php
define("DB_HOST","35.166.18.143");
define("DB_USERNAME","brian.martey");
define("DB_PASSWORD","73f10fb2216b97f4");
define("DB_NAME","db__brian_martey");
?>
